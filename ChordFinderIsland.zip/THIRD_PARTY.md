# Pihak ketiga

## Beat This! (deteksi tempo/BPM)

Model `beat_this.onnx` (varian small0) adalah konversi ONNX dari **Beat This!** karya Francesco Foscarin,
Jan Schlüter dan Gerhard Widmer, Institute of Computational Perception, Johannes Kepler University Linz
(ISMIR 2024, "Beat This! Accurate Beat Tracking Without DBN Postprocessing").
Kode dan bobot asli: https://github.com/CPJKU/beat_this, lisensi MIT, Copyright (c) 2024 Institute of
Computational Perception, JKU Linz, Austria. Teks lisensi MIT lengkap ada di repo aslinya dan harus
disertakan bila model didistribusikan ulang.

Catatan penulis aslinya: sebagian data latih berisi musik berhak cipta atau berlisensi Creative Commons terbatas;
bobot dirilis sebagai artefak riset. Pertimbangkan hal ini sebelum rilis komersial.

Pustaka pendukung di app: ONNX Runtime (MIT, Microsoft). `engine/BeatMel.kt` mengikuti frontend mel milik
beat_this dan port C++ `mosynthkey/beat_this_cpp` (MIT) sebagai referensi uji.
