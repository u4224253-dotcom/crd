# Chord Finder Island (native Android)

Port bertahap dari `chord-finder-island-mockup.html` ke Kotlin + Jetpack Compose.

Status: **Mode Resting** (pil 150 x 30 dengan mata yang menoleh dan berkedip acak, default saat island muncul), **Mode 2 — Upload / Analisis / Selesai** dan **Mode 3 — Preview** (island 420 x 96) sudah selesai. **Mode 4 — Akor** sekarang memakai hasil analisis sungguhan: carousel tiga akor gitar (tengah besar, kiri-kanan lebih kecil) yang mengikuti posisi lagu.

Alur: tidak ada pilihan tools. Upload audio -> analisis akor selesai dulu, lalu analisis BPM berjalan otomatis (satu proses). BPM tampil di mode Selesai ("Selesai · 128 BPM"), di notifikasi, dan kecil di tengah bawah mode Akor. Nomor mode: 2 = Upload/Analisis/Selesai, 3 = Preview, 4 = Akor.

Mode Resting: island selalu mulai dalam mode Resting. Ketuk island = buka mode yang tadi (pertama kali: Pilih tools).
Ketuk area kosong di mode mana pun (di luar tombol, panah, progres lagu, dan zona upload) = kembali ke Resting;
ketuk lagi untuk kembali ke mode terakhir. Analisis dan musik tetap jalan di latar saat Resting.
Di overlay, jendela ikut mengecil saat Resting sehingga tidak menghalangi sentuhan di bawahnya.

Pindah mode: panah kiri/kanan di island, atau geser ke samping di island.
Preview: sampul, judul + info file, mundur/maju 10 dtk, play/pause, waktu, progres (ketuk atau geser untuk melompat), equalizer.

Build: push ke GitHub (branch `main`), buka tab Actions > Build APK. APK debug ada di Artifacts.
Taruh isi folder ini di root repo (folder `.github/` harus di root).

## Island di luar aplikasi (overlay)

Tombol **Bawa island keluar** (di bawah island) memindahkan island ke jendela overlay yang dijalankan service foreground
(`IslandService`). Island menempel di tepi atas layar dan tetap ada walau aplikasi ditutup atau di-swipe dari recent.

- Pertama kali: izinkan **Tampil di atas aplikasi lain**, lalu kembali ke aplikasi (island otomatis muncul).
- Menutup: tombol **Tutup island di luar app** atau aksi **Tutup island** di notifikasi.
- Dari overlay, "pilih file" membuka `PickerActivity` (tembus pandang) lalu kembali ke app yang sedang dibuka.
- Island di dalam app dan island overlay punya state sendiri-sendiri; saat overlay dinyalakan, island di dalam app disembunyikan dan di-reset.

## Ukuran island

Di halaman aplikasi ada panel **Tampilan island** (dua slider: Ukuran 50 sampai 100 persen, dan Opasitas card 0 sampai 150 persen). Ukuran berlaku di semua mode kecuali Resting; Opasitas card (badan + telinga hitam island) berlaku di semua mode termasuk Resting. Berlaku di island dalam app maupun overlay, dan tersimpan. Tombol **Atur ulang** mengembalikan ke 100 persen.

## Mesin akor

Analisis akor sungguhan (bukan demo): CNN+BiLSTM ChordMini 3 fold, Kotlin murni tanpa library eksternal, jalan di HP tanpa internet.
Alur: audio (MediaCodec) -> mono 22.050 Hz -> CQT -> tiap fold -> Viterbi 301 akor. Model: `app/src/main/assets/cnn.lkm` (5,6 MB).

- Kode mesin: package `engine/` (`CnnChordEngine`, `AudioDecoder`, `ChordNames`, dan lain-lain), diambil dari LayKit.
- `ChordHub`: satu pusat hasil untuk seluruh proses (island dalam app dan overlay berbagi mesin dan hasil). Satu pekerjaan pada satu waktu; pekerjaan baru membatalkan yang lama.
- File yang diterima: audio dan video (mp4, mkv, webm, mov, dan sejenisnya; yang dianalisis trek audionya, video tanpa suara ditolak dengan pesan singkat). Pemilih file meminta izin baca permanen supaya file tetap terbuka setelah app ditutup.
- Batas: audio maksimal 20 menit. Kalau memori HP tidak cukup atau file tidak punya trek audio, island kembali ke mode Upload dengan pesan singkat.
- Mode Akor: akor tengah mengikuti posisi lagu; akor "tidak ada" dibuang dan akor sama yang berturutan digabung. Diagram gitar tersedia untuk semua akor model (akor ekstensi 9/11/13/m9/maj9 memakai bentuk yang paling dekat).
- Akor sebelumnya/selanjutnya: ketuk akor di kiri/kanan. Lagu ikut lompat ke waktu mulai akor itu (pemutar tetap main atau jeda seperti sebelumnya). Di awal/akhir lagu yang tidak punya tetangga, ketukan tidak melakukan apa-apa.
- Penulisan nama: mayor polos ditulis tanpa akhiran dan minor dengan "m" (A, Am); akor lain: Am7, Amaj7, A7, Asus4, Adim dan seterusnya. Nama panjang seperti D♭m7/B♭ otomatis dikecilkan supaya muat.

## Percepatan CNN (C++ / NDK)

Sekitar 94% waktu analisis ada di CNN. Sejak v0.10 CNN dijalankan oleh `libcfcnn.so` (`app/src/main/cpp/`, jembatan Kotlin: `engine/NativeCnn.kt`):
konvolusi dikerjakan per ubin 4 posisi lebar x 16 channel dengan akumulator di register (NEON `fmla` di arm64), hasilnya sama dengan jalur Kotlin
(selisih ~1e-6 relatif terhadap referensi float64). Kalau library tidak bisa dimuat atau gagal, `CnnFeatureExtractor` otomatis memakai jalur Kotlin lama.

- Build butuh NDK 27.0.12077973 dan CMake 3.22.1 (workflow sudah memasangnya lewat `sdkmanager`). ABI: arm64-v8a dan armeabi-v7a.
- Lama analisis tercatat di logcat: tag `ChordHub`, pesan "analisis selesai ... ms, CNN native=true".
- Pembatalan dari tombol Batalkan tetap berfungsi: callback progres melempar `CancellationException`, diteruskan lewat JNI.

## Tes kesesuaian (tools/parity)

Skrip Python untuk memeriksa mesin tanpa HP (butuh numpy, scipy, librosa, soxr):

- `cqt_parity.py <cnn.lkm>`: CQT dan resampler (tiruan `CqtCnn.kt` / `Resampler.kt`) vs `librosa.hybrid_cqt` / `librosa.resample`. Hasil terakhir: selisih relatif ~4e-4, korelasi 1,000000.
- `cnn_ref_test.py <cnn.lkm> <libcfcnn.so> [frames] [threads] [cqt.npy]`: kernel C++ vs referensi numpy float32 dan float64 per fold, plus uji pembatalan dan argumen salah.
  Library uji: `g++ -std=c++17 -O3 -shared -fPIC -pthread app/src/main/cpp/cnn_core.cpp -o libcfcnn_test.so`.
- `bench.py <cnn.lkm> <libcfcnn.so> <frames>`: kecepatan per fold dan per stage (GMAC/s).

## Tempo (BPM)

Setelah akor selesai, analisis yang sama juga menghitung BPM dan menampilkannya di mode Selesai
("Selesai · 128 BPM") dan di notifikasi hasil. Mesinnya **Beat This!** (JKU Linz, MIT) lewat ONNX Runtime:
audio mono 22.050 Hz (hasil resample yang sama dengan mesin akor) -> log-mel 128 pita 50 fps (`engine/BeatMel.kt`)
-> model per chunk 1500 frame (`engine/BeatThisEngine.kt`) -> puncak beat -> BPM (`engine/BeatPost.kt`: median
interval, dihaluskan regresi linear bila temponya stabil).

- Model: `app/src/main/assets/beat_this.onnx` (varian small, sekitar 10 MB). Workflow mengunduhnya otomatis saat build
  (dengan cek SHA-256). Kalau berkas sudah ada di repo, unduhan dilewati; kalau unduhan gagal, APK tetap jadi **tanpa BPM**
  (analisis akor tidak terganggu).
- Kegagalan tempo tidak pernah menggagalkan analisis akor; hasilnya hanya tanpa BPM. Lama tempo tercatat di logcat: tag `ChordHub`, pesan "tempo ... ms".
- BPM bisa meleset setengah/dua kali pada lagu tertentu (kesalahan oktaf), seperti semua pelacak tempo.
- Tes bagian non-jaringan (mel vs port C++, chunking, puncak, BPM): `tools/beat/mel_parity.sh`.
- Lisensi dan atribusi: `THIRD_PARTY.md`. APK membesar karena ONNX Runtime (dua ABI).

## Analisis di latar

- Island overlay: service foreground overlay sudah menjaga proses tetap hidup.
- Island di dalam app: saat analisis berjalan, `AnalysisService` (foreground service, tipe dataSync) menjaga proses tetap hidup walau app dipindah ke latar. Notifikasi menampilkan progres dengan tombol **Batalkan**. Kalau selesai saat app tidak tampil, muncul notifikasi hasil.
- Menutup app (swipe dari recent, atau tampilan dibuat ulang sistem) tidak lagi membatalkan analisis di island dalam app: `AnalysisService` menjaga prosesnya, dan `ChordHub` tetap memegang pekerjaan serta hasilnya. Selesai saat app tertutup = muncul notifikasi hasil.
- Dibuka lagi (ketuk notifikasi atau ikon app): island dalam app menyambung ke analisis yang masih jalan (progres lanjut dari posisi terakhir) atau langsung ke hasilnya, dan pemutar memuat file yang sama. Izin baca file diambil permanen saat file dipilih supaya tetap bisa dibuka setelah app ditutup.
- Bertahan selama proses app masih hidup. Kalau sistem mematikan prosesnya (memori habis, Paksa berhenti), analisis ikut hilang.
- Island overlay tetap membatalkan analisisnya saat island ditutup.
