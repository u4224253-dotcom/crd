"""Tes kesesuaian: tiru CqtCnn.kt + Resampler.kt di numpy, bandingkan dengan librosa.

Pemakaian: python3 -I cqt_parity.py <path cnn.lkm>
"""
import struct
import sys

import numpy as np
import scipy.sparse as sp
import librosa

LKM = sys.argv[1]


# ---------------------------------------------------------------- LKM
def read_lkm(path):
    b = open(path, "rb").read()
    assert b[:4] == b"LKCM"
    ver, count = struct.unpack_from("<II", b, 4)
    assert ver == 1
    pos = 12
    f, i, bl = {}, {}, {}
    for _ in range(count):
        (nl,) = struct.unpack_from("<H", b, pos); pos += 2
        name = b[pos:pos + nl].decode(); pos += nl
        dtype, rank = b[pos], b[pos + 1]; pos += 2
        dims = struct.unpack_from("<" + "I" * rank, b, pos); pos += 4 * rank
        n = int(np.prod(dims)) if rank else 1
        if dtype == 0:
            f[name] = np.frombuffer(b, "<f4", n, pos).reshape(dims).copy(); pos += 4 * n
        elif dtype == 1:
            i[name] = np.frombuffer(b, "<i4", n, pos).copy(); pos += 4 * n
        else:
            bl[name] = b[pos:pos + dims[0]]; pos += dims[0]
    return f, i, bl


F, I, B = read_lkm(LKM)

# ---------------------------------------------------------------- Resampler.kt (port)
BETA, PHASES, PASSBAND_END = 10.0, 512, 0.8
_kcache = {}


def kernel(src, dst):
    key = (src, dst)
    if key in _kcache:
        return _kcache[key]
    ratio = dst / src
    lp = min(1.0, ratio)
    fc = 0.5 * lp * (PASSBAND_END + 1.0) / 2.0
    half_len = int(np.ceil(31.0 / lp))
    taps = 2 * half_len
    i0b = np.i0(BETA)
    table = np.zeros((PHASES + 1, taps), np.float64)
    j = np.arange(taps)
    for p in range(PHASES + 1):
        frac = p / PHASES
        d = (j - half_len + 1) - frac
        u = d / half_len
        win = np.where((u <= -1) | (u >= 1), 0.0, np.i0(BETA * np.sqrt(np.clip(1 - u * u, 0, None))) / i0b)
        x = 2.0 * fc * d
        s = np.where(x == 0, 1.0, np.sinc(x))  # np.sinc = sin(pi x)/(pi x)
        row = 2.0 * fc * s * win
        table[p] = row / row.sum()
    k = (half_len, taps, table.astype(np.float32))
    _kcache[key] = k
    return k


def resample(x, src, dst, energy_scale=False):
    if src == dst:
        return x.copy()
    half_len, taps, table = kernel(src, dst)
    n_out = int(np.ceil(len(x) * dst / src))
    gain = np.sqrt(src / dst) if energy_scale else 1.0
    o = np.arange(n_out)
    pos = o.astype(np.float64) * src / dst
    i0 = np.floor(pos).astype(np.int64)
    pf = (pos - i0) * PHASES
    p = pf.astype(np.int64)
    w1 = (pf - p).astype(np.float32)
    w0 = 1.0 - w1
    base = i0 - half_len + 1
    xp = np.pad(x.astype(np.float32), (half_len, taps + half_len))
    out = np.zeros(n_out, np.float32)
    CH = 20000
    for a in range(0, n_out, CH):
        b = min(n_out, a + CH)
        idx = (base[a:b] + half_len)[:, None] + np.arange(taps)[None, :]
        seg = xp[idx]
        tab = table[p[a:b]] * w0[a:b, None] + table[p[a:b] + 1] * w1[a:b, None]
        out[a:b] = (seg * tab).sum(1)
    return out * np.float32(gain)


def halve(x):
    return resample(x, 2, 1, True)


# ---------------------------------------------------------------- CqtCnn.kt (port)
meta = I["cqt.meta"]
early_down, n_oct, n_bins, n_full, n_pseudo, hop, sr_m, bpo = [int(v) for v in meta[:8]] if len(meta) >= 8 else (*[int(v) for v in meta], None, None)
tuning = float(F["cqt.tuning"].ravel()[0])
print("cqt.meta", list(meta), "tuning", tuning)


def csr(prefix, kind):
    ptr, idx = I[prefix + ".indptr"], I[prefix + ".indices"]
    return ptr, idx


octaves = []
for k in range(n_oct):
    om = I[f"cqt.o{k}.meta"]
    ptr, idx = I[f"cqt.o{k}.indptr"], I[f"cqt.o{k}.indices"]
    re_, im_ = F[f"cqt.o{k}.re"].ravel(), F[f"cqt.o{k}.im"].ravel()
    o = dict(hop=int(om[0]), nfft=int(om[1]), first=int(om[2]), nb=int(om[3]), halve=bool(om[4]))
    o["mat"] = sp.csr_matrix((re_.astype(np.complex64) + 1j * im_.astype(np.complex64), idx, ptr), shape=(o["nb"], o["nfft"] // 2 + 1))
    octaves.append(o)
    print(f"  oktaf {k}: hop={o['hop']} nfft={o['nfft']} first={o['first']} nb={o['nb']} halve_after={o['halve']} nnz={len(idx)}")
pseudo = None
if n_pseudo > 0:
    pm = I["cqt.p.meta"]
    ptr, idx, w = I["cqt.p.indptr"], I["cqt.p.indices"], F["cqt.p.w"].ravel()
    pseudo = dict(nfft=int(pm[0]), nb=int(pm[1]), first=int(pm[2]))
    pseudo["mat"] = sp.csr_matrix((w, idx, ptr), shape=(pseudo["nb"], pseudo["nfft"] // 2 + 1))
    print(f"  pseudo: nfft={pseudo['nfft']} nb={pseudo['nb']} first={pseudo['first']} nnz={len(idx)}")


def ceil_div(a, b):
    return -(-a // b)


def cqt_port(y):
    ln = ceil_div(len(y), early_down) if early_down > 1 else len(y)
    frames = 2 ** 62
    for o in octaves:
        frames = min(frames, 1 + ln // o["hop"])
        if o["halve"]:
            ln = ceil_div(ln, 2)
    if pseudo:
        frames = min(frames, 1 + len(y) // hop)
    out = np.zeros((frames, n_bins), np.float32)
    cur = resample(y, early_down, 1, True) if early_down > 1 else y
    for o in octaves:
        half = o["nfft"] // 2
        padded = np.pad(cur, (half, o["nfft"] + 8))
        win = np.lib.stride_tricks.sliding_window_view(padded, o["nfft"])[:: o["hop"]][:frames]
        spec = np.fft.rfft(win.astype(np.float32), axis=1)  # [T, nfft/2+1]
        resp = o["mat"] @ spec.T  # [nb, T]
        out[:, o["first"]:o["first"] + o["nb"]] = np.abs(resp).T
        if o["halve"]:
            cur = halve(cur)
    if pseudo:
        nfft = pseudo["nfft"]
        half = nfft // 2
        hann = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(nfft) / nfft)).astype(np.float32)
        padded = np.pad(y, (half, nfft + 8))
        win = np.lib.stride_tricks.sliding_window_view(padded, nfft)[::hop][:frames] * hann
        mag = np.abs(np.fft.rfft(win.astype(np.float32), axis=1))
        resp = pseudo["mat"] @ mag.T
        out[:, pseudo["first"]:pseudo["first"] + pseudo["nb"]] = resp.T
    return out


# ---------------------------------------------------------------- sinyal uji
rng = np.random.default_rng(7)
SR_IN = 44100
dur = 14.0
t = np.arange(int(dur * SR_IN)) / SR_IN
sig = np.zeros_like(t)
chords = [(220.0, 277.18, 329.63), (196.0, 246.94, 293.66), (174.61, 220.0, 261.63), (261.63, 329.63, 392.0)]
seg = dur / len(chords)
for ci, fr in enumerate(chords):
    m = (t >= ci * seg) & (t < (ci + 1) * seg)
    for f0 in fr:
        for h, amp in enumerate([1.0, 0.5, 0.33, 0.2, 0.12, 0.08], start=1):
            sig[m] += amp * np.sin(2 * np.pi * f0 * h * t[m] + rng.uniform(0, 6.28))
    # transien "strum"
    st = int(ci * seg * SR_IN)
    sig[st:st + 2000] += rng.normal(0, 0.8, 2000) * np.exp(-np.arange(2000) / 400)
sig += rng.normal(0, 0.03, len(sig))
# bass dan perkusi kasar
sig += 0.4 * np.sin(2 * np.pi * 55 * t) * (np.sin(2 * np.pi * 2 * t) > 0)
sig = (sig / np.abs(sig).max() * 0.7).astype(np.float32)

SR = 22050
HOP = hop
FMIN = float(librosa.note_to_hz("F#0"))

# referensi librosa
y_ref = librosa.resample(sig, orig_sr=SR_IN, target_sr=SR, res_type="soxr_hq")
y_ours = resample(sig, SR_IN, SR)

n = min(len(y_ref), len(y_ours))
err = y_ours[:n] - y_ref[:n]
print(f"\n[1] RESAMPLER 44100->22050: panjang ref={len(y_ref)} ours={len(y_ours)}")
print(f"    RMS sinyal={np.sqrt((y_ref**2).mean()):.4f}  RMS selisih={np.sqrt((err**2).mean()):.2e}  rasio={np.sqrt((err**2).mean())/np.sqrt((y_ref**2).mean()):.2e}")
# batasi ke pita < 2.1 kHz (yang dipakai model)
Yr = np.fft.rfft(y_ref[:n]); Yo = np.fft.rfft(y_ours[:n]); fr_ = np.fft.rfftfreq(n, 1 / SR)
band = fr_ < 2100
print(f"    selisih spektral relatif pita <2.1kHz = {np.linalg.norm((Yo - Yr)[band]) / np.linalg.norm(Yr[band]):.2e}")

# CQT referensi (pakai tuning dari lkm)
def ref_cqt(y):
    return np.abs(librosa.hybrid_cqt(y, sr=SR, hop_length=HOP, fmin=FMIN, n_bins=n_bins, bins_per_octave=36, tuning=tuning)).T.astype(np.float32)


def cmp(a, b, label):
    T = min(len(a), len(b))
    a, b = a[:T], b[:T]
    sl = slice(18, 270)
    A, Bm = a[:, sl], b[:, sl]
    rel = np.linalg.norm(A - Bm) / np.linalg.norm(Bm)
    cos = (A * Bm).sum(1) / (np.linalg.norm(A, axis=1) * np.linalg.norm(Bm, axis=1) + 1e-12)
    mx = np.abs(A - Bm).max() / Bm.max()
    print(f"    {label}: frame ours={len(a)} ref={len(b)} | rel L2={rel:.3e} | cos frame min={cos.min():.5f} mean={cos.mean():.6f} | max|d|/max={mx:.2e}")
    # per bagian bin
    for nm, lo, hi in [("bin 18-107 (bawah)", 18, 108), ("bin 108-197 (tengah)", 108, 198), ("bin 198-269 (atas)", 198, 270)]:
        r = np.linalg.norm(a[:, lo:hi] - b[:, lo:hi]) / np.linalg.norm(b[:, lo:hi])
        print(f"        {nm}: rel L2={r:.3e}")
    return rel


print("\n[2] CQT SAJA (masukan sama = hasil librosa 22.050 Hz): port vs librosa.hybrid_cqt")
c_ref = ref_cqt(y_ref)
c_port = cqt_port(y_ref)
cmp(c_port, c_ref, "port(CQT) vs librosa")

print("\n[3] END-TO-END: (resampler kita + CQT kita) vs (librosa penuh)")
c_ours = cqt_port(y_ours)
cmp(c_ours, c_ref, "ours vs librosa")

# setelah InstanceNorm-ish: z-score global agar selisih skala tak dihitung
def zs(a):
    a = a[:, 18:270]
    return (a - a.mean()) / (a.std() + 1e-9)

T = min(len(c_ours), len(c_ref))
print(f"\n    korelasi global (z-score) ours vs librosa = {np.corrcoef(zs(c_ours[:T]).ravel(), zs(c_ref[:T]).ravel())[0,1]:.6f}")
np.save(sys.argv[2] if len(sys.argv) > 2 else "/tmp/cqt_ours.npy", c_ours)
