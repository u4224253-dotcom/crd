#include "MelSpectrogram.h"
#include <cstdio>
#include <vector>
int main(){
  FILE* f=fopen("audio.f32","rb"); fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
  std::vector<float> a(sz/4); fread(a.data(),4,a.size(),f); fclose(f);
  MelSpectrogram m; auto s=m.compute(a);
  FILE* o=fopen("mel_ref.f32","wb");
  for(auto& r: s) fwrite(r.data(),4,r.size(),o);
  fclose(o); printf("frames=%zu\n", s.size());
}
