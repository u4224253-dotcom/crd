package com.chordfinder.island.engine
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
fun readF32(p: String): FloatArray { val b = ByteBuffer.wrap(File(p).readBytes()).order(ByteOrder.LITTLE_ENDIAN); return FloatArray(b.remaining()/4){ b.getFloat() } }
fun main() {
    val a = readF32("audio.f32"); val ref = readF32("mel_ref.f32")
    val r = BeatMel().compute(a)
    println("frames kotlin=${r.frames} ref=${ref.size / 128}")
    var maxd = 0f; var sum = 0.0
    for (i in ref.indices) { val d = kotlin.math.abs(ref[i] - r.data[i]); if (d > maxd) maxd = d; sum += d }
    println("max|diff|=$maxd mean|diff|=${sum / ref.size}  (nilai log-mel berkisar ${ref.min()}..${ref.max()})")
}
