#!/usr/bin/env bash
# Menguji engine/BeatMel.kt dan engine/BeatPost.kt:
#  1. mel Kotlin vs port C++ beat_this_cpp (MIT) pada audio sintetis -> selisih maks harus ~1e-5
#  2. chunking/agregasi/puncak/BPM pada logit sintetis (tanpa model)
# Butuh: g++, python3 + numpy, git, kotlinc (>= 2.0) dan java di PATH.
set -euo pipefail
cd "$(dirname "$0")"
ENG=../../app/src/main/java/com/chordfinder/island/engine
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
git clone -q --depth 1 https://github.com/mreineck/pocketfft "$W/pf"
git clone -q --depth 1 https://github.com/mosynthkey/beat_this_cpp "$W/btc"
cp "$W/pf/pocketfft_hdronly.h" "$W/"
cp ref_mel.cpp MelTest.kt PostTest.kt "$W/"
python3 - "$W" <<'PY'
import sys, numpy as np
w = sys.argv[1]; rng = np.random.default_rng(7); sr = 22050; n = sr*6+137; t = np.arange(n)/sr
x = 0.3*np.sin(2*np.pi*220*t) + 0.2*np.sin(2*np.pi*1760*t*(1+0.05*t)) + 0.05*rng.standard_normal(n)
for k in range(int(n/sr*2)):
    i = int(k*0.5*sr); seg = x[i:i+200]; seg += 0.8*np.hanning(200)[:len(seg)]
x.astype(np.float32).tofile(w + "/audio.f32")
PY
( cd "$W" && g++ -O2 -std=c++17 -I. -Ibtc/Source ref_mel.cpp btc/Source/MelSpectrogram.cpp -o ref_mel && ./ref_mel )
kotlinc "$ENG/Fft.kt" "$ENG/BeatMel.kt" "$ENG/BeatPost.kt" "$W/MelTest.kt" -include-runtime -d "$W/mel.jar" 2>/dev/null
kotlinc "$ENG/Fft.kt" "$ENG/BeatMel.kt" "$ENG/BeatPost.kt" "$W/PostTest.kt" -include-runtime -d "$W/post.jar" 2>/dev/null
( cd "$W" && java -cp mel.jar com.chordfinder.island.engine.MelTestKt && java -cp post.jar com.chordfinder.island.engine.PostTestKt | grep -v "rows<=" )
