package com.chordfinder.island

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Seluruh state satu island: cahaya, alur analisis, pemutar, halaman (mode) yang tampil.
 * Dipakai dua tempat: layar aplikasi (MainActivity) dan jendela overlay (IslandService).
 */
class IslandState(private val ctx: Context, private val scope: CoroutineScope) {
    val glow = GlowController()
    val flow = AnalyzeFlow(ctx.applicationContext, scope, glow) { flash(it, 3200) }
    val player = PlayerController(ctx)

    /** Mode yang tampil: 1 = Pilih tools (default), 2 = Upload/Analisis/Selesai, 3 = Preview, 4 = Akor. */
    var page by mutableIntStateOf(1)
    var hover by mutableStateOf(false)

    /**
     * Mode Resting: island menciut jadi pil kecil bermata. Defaultnya aktif saat island muncul.
     * [page] dan fase analisis tidak disentuh, jadi [wake] otomatis kembali ke mode terakhir.
     */
    var resting by mutableStateOf(true)
    var msg by mutableStateOf(MSG_DEFAULT)

    fun go(n: Int) { page = n.coerceIn(1, 4) }

    /** Ketuk area kosong di mode mana pun: masuk mode Resting. */
    fun rest() { hover = false; glow.hot(false); resting = true }

    /**
     * Hook khusus overlay: dipanggil sebelum keluar dari Resting. Hook harus membesarkan jendela dulu,
     * lalu memanggil `go` setelah jendela siap, supaya animasi membuka tidak terpotong jendela yang masih kecil.
     */
    var beforeWake: ((go: () -> Unit) -> Unit)? = null

    /** Ketuk island Resting: buka lagi mode yang tadi (pertama kali = mode Upload). */
    fun wake() {
        val hook = beforeWake
        if (hook == null) resting = false else hook { resting = false }
    }

    /** reset() di HTML: batalkan analisis, hentikan pemutar, kembali ke mode Upload. */
    fun resetAll() { flow.reset(); player.clear(); page = 2 }

    private var msgJob: Job? = null

    /** Tampilkan pesan sementara di zona upload, lalu kembali ke teks biasa. */
    fun flash(text: String, ms: Long = 1800) {
        msgJob?.cancel()
        msgJob = scope.launch { msg = text; delay(ms); msg = MSG_DEFAULT }
    }

    fun notAudio() = flash(MSG_BAD)

    /** Terima file; false kalau bukan audio. */
    fun accept(uri: Uri): Boolean {
        val info = readAudio(ctx, uri) ?: return false
        // izin baca tetap berlaku walau layar aplikasi ditutup (analisis di latar masih butuh membuka file ini)
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        player.load(info)
        flow.accept(info)
        return true
    }

    /**
     * Island ditutup. [keepWork] = true (layar aplikasi): analisis yang masih jalan atau hasil yang sudah ada
     * dibiarkan di [ChordHub] supaya bisa disambung lagi saat aplikasi dibuka.
     */
    fun release(keepWork: Boolean = false) {
        if (keepWork) flow.detach() else flow.release()
        player.release()
    }

    /** Aplikasi dibuka lagi: sambung ke analisis di latar (atau hasilnya). Mengembalikan true kalau ada yang disambung. */
    fun adoptRunning(): Boolean {
        val info = ChordHub.current ?: return false
        val s = ChordHub.state
        if (s is ChordHub.St.Idle) return false
        player.load(info)
        flow.adopt(info, s.id)
        page = 2
        return true
    }
}

/** Jembatan untuk PickerActivity (dibuka dari overlay) supaya file yang dipilih sampai ke island overlay. */
object IslandBridge {
    @Volatile var state: IslandState? = null
}
