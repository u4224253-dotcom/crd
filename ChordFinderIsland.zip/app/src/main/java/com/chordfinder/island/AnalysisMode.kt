package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

// Ikon SVG dari mock-up (viewBox 24 x 24), di-parse sekali.
private fun svgPath(d: String): Path = PathParser().parsePathString(d).toPath()

private val ICON_CLOSE = svgPath("M6 6l12 12M18 6 6 18")
private val ICON_AGAIN = svgPath("M20 12a8 8 0 1 1-2.3-5.6M20 4v4h-4")
private val ICON_UPLOAD = svgPath("M12 16V4M7 9l5-5 5 5M5 20h14")
private val ICON_CHECK = svgPath("m5 12.5 4.5 4.5L19 7.5")

private val DIM = Color.White.copy(alpha = .5f)
private val GREEN = Color(0xFF33E07A)

/**
 * Lapisan island (.ly di HTML): muncul .32 dtk setelah jeda .2 dtk, hilang .2 dtk (ease),
 * jadi pergantian mode berupa crossfade seperti di mock-up.
 */
@Composable
fun Layer(show: Boolean, bleed: Boolean = false, content: @Composable BoxScope.() -> Unit) {
    val fade = remember { Animatable(0f) }
    LaunchedEffect(show) {
        if (show) fade.animateTo(1f, tween(320, delayMillis = 200, easing = Tok.Ease))
        else fade.animateTo(0f, tween(200, easing = Tok.Ease))
    }
    if (show || fade.value > 0.001f) {
        Box(
            (if (bleed) Modifier.bleedEars() else Modifier.fillMaxSize()).graphicsLayer { alpha = fade.value },
            content = content,
        )
    }
}

/** Tombol pil (.pill): latar putih 12 persen, ikon 13 dp + teks 12 dp, isi di tengah. */
@Composable
private fun Pill(x: Float, y: Float, w: Float, h: Float, label: String, icon: Path, onClick: () -> Unit) {
    val fs = with(LocalDensity.current) { 12f.dp.toSp() }
    Box(
        Modifier
            .offset(x.dp, y.dp)
            .size(w.dp, h.dp)
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = .12f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Canvas(Modifier.size(13.dp)) {
                val k = size.width / 24f
                scale(k, k, Offset.Zero) {
                    drawPath(icon, Color.White, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            BasicText(label, style = TextStyle(color = Color.White, fontSize = fs), maxLines = 1, softWrap = false)
        }
    }
}

/** Ring progres (.pk-ring): 44 dp di titik (66, 44), viewBox 30, r 11, garis 3.2, mulai dari atas. */
@Composable
private fun Ring(track: Color, arc: Color, p: () -> Float) {
    Canvas(Modifier.placeAt(66f, 44f).size(44.dp)) {
        val k = size.width / 30f
        val r = 11f * k
        val sw = 3.2f * k
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(track, radius = r, center = c, style = Stroke(width = sw))
        val pp = p().coerceIn(0f, 1f)
        if (pp > .002f) {
            drawArc(
                arc, startAngle = -90f, sweepAngle = 360f * pp, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(2f * r, 2f * r),
                style = Stroke(width = sw, cap = StrokeCap.Round),
            )
        }
    }
}

/** Bar progres (.prog): 222 x 4 dp di (100, 61), isian gradasi #66dbff ke #2d6bff. */
@Composable
private fun Bar(p: State<Float>) {
    Canvas(Modifier.placeAt(100f, 61f, 0f, .5f).size(222.dp, 4.dp)) {
        val rad = CornerRadius(size.height / 2f)
        drawRoundRect(Color.White.copy(alpha = .22f), cornerRadius = rad)
        val w = size.width * p.value.coerceIn(0f, 1f)
        if (w > 0f) {
            drawRoundRect(
                Brush.horizontalGradient(0f to Color(0xFF66DBFF), 1f to Color(0xFF2D6BFF), startX = 0f, endX = w),
                size = Size(w, size.height), cornerRadius = rad,
            )
        }
    }
}

/**
 * Tepi island (.edge): cahaya warna maskot berputar, komet ganda, cincin 2.5 dp, 2.6 dtk per putaran.
 * Dipakai di Layer(bleed = true): kanvas selebar badan + telinga, cincin mengikuti siluet termasuk lengkung atas.
 */
@Composable
fun SpinEdge() {
    val infinite = rememberInfiniteTransition(label = "edge")
    val ang = infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "ang",
    )
    val sil = remember { islandPath(Tok.E, Tok.W, Tok.H, Tok.E, Tok.R) }
    val cyan = Color(0xFF19B8FF); val indigo = Color(0xFF2D5BFF); val violet = Color(0xFF7B4BFF)
    val cyan0 = cyan.copy(alpha = 0f); val violet0 = violet.copy(alpha = 0f)
    Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
        val d = density
        val ctr = Offset(Tok.E + Tok.W / 2f, Tok.H / 2f)
        val brush = Brush.sweepGradient(
            0f to cyan0, 45f / 360f to cyan, 80f / 360f to indigo, 120f / 360f to violet, 150f / 360f to violet0,
            180f / 360f to cyan0, 225f / 360f to cyan, 260f / 360f to indigo, 300f / 360f to violet, 330f / 360f to violet0,
            1f to violet0,
            center = ctr,
        )
        scale(d, d, Offset.Zero) {
            clipPath(sil) {
                // topeng: garis tepi siluet selebar 2 x 2.5 (separuh luar terpotong clip, sisa 2.5 di dalam)
                drawPath(sil, Color.White, style = Stroke(width = 5f))
                rotate(ang.value - 90f, ctr) {
                    drawCircle(brush, radius = 400f, center = ctr, alpha = 1f, blendMode = BlendMode.SrcIn)
                }
            }
        }
    }
}

/** Fase 2: analisis. Baris atas: nama, tahap, tombol batal. Baris bawah: bar dan sisa waktu. */
@Composable
fun AnalyzeMode(progress: Float, name: String, stage: String, eta: Float?, onCancel: () -> Unit) {
    val lagged = animateFloatAsState(progress, tween(250, easing = LinearEasing), label = "anp")
    Ring(Color.White.copy(alpha = .18f), Color(0xFF5EC2FF)) { lagged.value }
    CText("${(progress * 100f).roundToInt()}%", 66f, 44f, 11.5f, weight = FontWeight.Bold)
    CText(name, 100f, 25f, 14f, weight = FontWeight.SemiBold, ax = 0f, maxW = 172f)
    CText(stage, 100f, 41f, 11f, color = DIM, ax = 0f, maxW = 172f)
    Pill(284f, 15f, 92f, 24f, "Batalkan", ICON_CLOSE, onCancel)
    Bar(lagged)
    CText(if (eta != null) "-" + fmtTime(eta) else "…", Tok.W - 44f, 61f, 11f, color = DIM, ax = 1f)
}

/** Fase 3: selesai. Ring hijau penuh + centang, tombol Analisis ulang dan Ganti file. */
@Composable
fun DoneMode(name: String, onAgain: () -> Unit, onChange: () -> Unit, bpm: Double? = null) {
    Ring(GREEN.copy(alpha = .28f), GREEN) { 1f }
    Canvas(Modifier.placeAt(66f, 44f).size(18.dp)) {
        val k = size.width / 24f
        scale(k, k, Offset.Zero) {
            drawPath(ICON_CHECK, GREEN, style = Stroke(width = 2.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
    CText(name, 100f, 23f, 14f, weight = FontWeight.SemiBold, ax = 0f, maxW = 276f)
    CText(if (bpm != null) "Selesai · ${ChordHub.bpmText(bpm)} BPM" else "Analisis akor selesai", 100f, 39f, 11f, color = DIM, ax = 0f)
    Pill(100f, 52f, 118f, 24f, "Analisis ulang", ICON_AGAIN, onAgain)
    Pill(226f, 52f, 92f, 24f, "Ganti file", ICON_UPLOAD, onChange)
}
