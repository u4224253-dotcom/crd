package com.chordfinder.island.engine

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import java.util.concurrent.CancellationException
import kotlin.math.max

/**
 * Decode trek audio (mp3/m4a/aac/wav/video mp4, apa pun yang bisa dibuka MediaCodec) menjadi PCM mono float [-1,1].
 * Laju sampel dibiarkan seperti aslinya; ChordEngine yang me-resample ke 22.050 Hz.
 *
 * Memanggil [cancelled] di tiap putaran supaya bisa dihentikan dari luar (lempar CancellationException).
 */
internal object AudioDecoder {
    class Pcm(val samples: FloatArray, val sampleRate: Int)

    /** Batas panjang audio. 20 menit mono float ~ 200 MB di 44,1 kHz; lebih dari itu berisiko kehabisan memori di HP. */
    const val MAX_SECONDS = 20 * 60

    fun decodeMono(
        ctx: Context,
        uri: Uri,
        cancelled: () -> Boolean = { false },
        onProgress: (Float) -> Unit = {},
    ): Pcm {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) throw IllegalStateException("Berkas ini tidak punya trek audio")
            ex.selectTrack(track)

            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durUs > MAX_SECONDS * 1_000_000L) {
                throw IllegalStateException("Audio terlalu panjang (maksimal ${MAX_SECONDS / 60} menit)")
            }
            var floatPcm = false

            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var out = FloatArray(max(1 shl 16, (durUs / 1_000_000.0 * sr).toInt() + sr))
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var lastP = -1f

            while (!outDone) {
                if (cancelled()) throw CancellationException("dibatalkan")
                if (!inDone) {
                    val i = c.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val ib = c.getInputBuffer(i)!!
                        val sz = ex.readSampleData(ib, 0)
                        if (sz < 0) {
                            c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(i, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = c.dequeueOutputBuffer(info, 10_000)
                when {
                    o >= 0 -> {
                        if (info.size > 0) {
                            val ob = c.getOutputBuffer(o)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            val chn = max(1, ch)
                            val frames: Int
                            if (floatPcm) {
                                val fb = ob.asFloatBuffer()
                                frames = fb.remaining() / chn
                                if (n + frames > out.size) out = out.copyOf(max(out.size * 2, n + frames))
                                for (k in 0 until frames) {
                                    var s = 0f
                                    for (q in 0 until chn) s += fb.get()
                                    out[n++] = s / chn
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                frames = sb.remaining() / chn
                                if (n + frames > out.size) out = out.copyOf(max(out.size * 2, n + frames))
                                for (k in 0 until frames) {
                                    var s = 0
                                    for (q in 0 until chn) s += sb.get().toInt()
                                    out[n++] = s / (32768f * chn)
                                }
                            }
                            if (n > sr.toLong() * MAX_SECONDS) {
                                throw IllegalStateException("Audio terlalu panjang (maksimal ${MAX_SECONDS / 60} menit)")
                            }
                            if (durUs > 0) {
                                val p = (info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f)
                                if (p - lastP >= 0.01f) { lastP = p; onProgress(p) }
                            }
                        }
                        c.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = c.outputFormat
                        sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        floatPcm = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                }
            }
            onProgress(1f)
            if (n == 0) throw IllegalStateException("Audio kosong")
            return Pcm(if (n == out.size) out else out.copyOf(n), sr)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }
}
