package com.chordfinder.island.engine

import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Tensor float32 sederhana: bentuk + data row-major. */
class Tensor(val shape: IntArray, val data: FloatArray)

/**
 * Kontainer model (.lkm), dibuat oleh tools/export_lkm.py.
 *
 * Format (little-endian):
 *   "LKCM" | u32 versi=1 | u32 jumlah_entri
 *   tiap entri: u16 panjang_nama | nama utf8 | u8 dtype (0=f32, 1=i32, 2=bytes)
 *               | u8 rank | u32 dims[rank] | data
 */
class LkmFile private constructor(
    private val floats: Map<String, Tensor>,
    private val ints: Map<String, IntArray>,
    private val blobs: Map<String, ByteArray>,
) {
    fun tensor(name: String): Tensor =
        floats[name] ?: throw IllegalArgumentException("Tensor '$name' tidak ada di berkas model")

    fun ints(name: String): IntArray =
        ints[name] ?: throw IllegalArgumentException("Array int '$name' tidak ada di berkas model")

    fun blob(name: String): ByteArray =
        blobs[name] ?: throw IllegalArgumentException("Blob '$name' tidak ada di berkas model")

    companion object {
        fun read(input: InputStream): LkmFile =
            parse(ByteBuffer.wrap(input.readBytes()).order(ByteOrder.LITTLE_ENDIAN))

        fun parse(buf: ByteBuffer): LkmFile {
            buf.order(ByteOrder.LITTLE_ENDIAN)
            val magic = ByteArray(4)
            buf.get(magic)
            require(String(magic, Charsets.US_ASCII) == "LKCM") { "Bukan berkas LKM" }
            val version = buf.int
            require(version == 1) { "Versi LKM $version tidak didukung" }
            val count = buf.int

            val floats = HashMap<String, Tensor>()
            val ints = HashMap<String, IntArray>()
            val blobs = HashMap<String, ByteArray>()

            repeat(count) {
                val nameLen = buf.short.toInt() and 0xFFFF
                val nameBytes = ByteArray(nameLen)
                buf.get(nameBytes)
                val name = String(nameBytes, Charsets.UTF_8)
                val dtype = buf.get().toInt()
                val rank = buf.get().toInt()
                val dims = IntArray(rank) { buf.int }
                var n = 1
                for (d in dims) n *= d
                when (dtype) {
                    0 -> {
                        val a = FloatArray(n)
                        buf.asFloatBuffer().get(a)
                        buf.position(buf.position() + n * 4)
                        floats[name] = Tensor(dims, a)
                    }
                    1 -> {
                        val a = IntArray(n)
                        buf.asIntBuffer().get(a)
                        buf.position(buf.position() + n * 4)
                        ints[name] = a
                    }
                    2 -> {
                        val a = ByteArray(dims[0])
                        buf.get(a)
                        blobs[name] = a
                    }
                    else -> throw IllegalArgumentException("dtype $dtype tidak dikenal untuk '$name'")
                }
            }
            return LkmFile(floats, ints, blobs)
        }
    }
}
