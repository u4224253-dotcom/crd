package com.chordfinder.island.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.res.AssetManager
import java.io.IOException
import java.nio.FloatBuffer

/**
 * Pelacak beat Beat This! (CPJKU, ISMIR 2024, lisensi MIT) lewat ONNX Runtime.
 * Alur: audio mono 22.050 Hz -> log-mel ([BeatMel]) -> model per chunk 1500 frame ([BeatPost]) ->
 * puncak beat -> BPM. Model: assets/beat_this.onnx (varian small, sekitar 10 MB), diunduh workflow saat build.
 *
 * Satu instance = satu pekerjaan pada satu waktu. Kalau berkas model tidak ada, [load] mengembalikan null
 * dan analisis akor tetap jalan tanpa BPM.
 */
class BeatThisEngine private constructor(
    private val env: OrtEnvironment,
    private val session: OrtSession,
) : AutoCloseable {

    /** [beats] dalam detik; [bpm] null kalau beat terlalu sedikit; [steady] 0..1 = seberapa stabil temponya. */
    class Result(val beats: FloatArray, val bpm: Double?, val steady: Float)

    private val inputName: String = session.inputNames.first()
    private val beatOutput: String = session.outputNames.let { names ->
        names.firstOrNull { it.contains("beat", true) && !it.contains("down", true) } ?: names.first()
    }
    private val mel = BeatMel()

    /**
     * @param pcm audio mono [-1,1] pada laju [sampleRate]; di-resample ke 22.050 Hz bila perlu.
     * @param onProgress 0..1; boleh melempar untuk membatalkan.
     */
    fun analyze(pcm: FloatArray, sampleRate: Int, onProgress: ((Float) -> Unit)? = null): Result {
        val y = if (sampleRate == BeatMel.SAMPLE_RATE) pcm else Resampler.resample(pcm, sampleRate, BeatMel.SAMPLE_RATE)
        val m = mel.compute(y) { onProgress?.invoke(it * 0.15f) }
        if (m.frames == 0) return Result(FloatArray(0), null, 0f)

        val starts = BeatPost.starts(m.frames)
        val agg = BeatPost.Aggregator(m.frames)
        for ((i, s) in starts.withIndex()) {
            val c = BeatPost.chunk(m.data, m.frames, s)
            agg.add(s, runChunk(c))
            onProgress?.invoke(0.15f + 0.85f * (i + 1) / starts.size)
        }
        val beats = BeatPost.pickBeats(agg.logits)
        val tempo = BeatPost.tempo(beats)
        return Result(beats, tempo?.bpm, tempo?.steady ?: 0f)
    }

    /** Satu pemanggilan model: spektrogram [1, rows, 128] -> logit beat per frame. */
    private fun runChunk(c: BeatPost.Chunk): FloatArray {
        val shape = longArrayOf(1, c.rows.toLong(), BeatMel.N_MELS.toLong())
        OnnxTensor.createTensor(env, FloatBuffer.wrap(c.data), shape).use { input ->
            session.run(mapOf(inputName to input), setOf(beatOutput)).use { out ->
                val t = out.get(0) as OnnxTensor
                val fb = t.floatBuffer
                val arr = FloatArray(fb.remaining())
                fb.get(arr)
                check(arr.size == c.rows) { "bentuk keluaran model tidak cocok: ${arr.size} != ${c.rows}" }
                return arr
            }
        }
    }

    override fun close() {
        session.close()
    }

    companion object {
        const val ASSET = "beat_this.onnx"

        /** Memuat model dari assets; null kalau berkasnya tidak ada atau gagal dimuat (fitur BPM dimatikan). */
        fun load(assets: AssetManager): BeatThisEngine? {
            val bytes = try {
                assets.open(ASSET).use { it.readBytes() }
            } catch (e: IOException) {
                return null
            }
            return try {
                val env = OrtEnvironment.getEnvironment()
                val opts = OrtSession.SessionOptions()
                opts.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
                BeatThisEngine(env, env.createSession(bytes, opts))
            } catch (e: Throwable) {
                android.util.Log.w("BeatThis", "model BPM gagal dimuat", e)
                null
            }
        }
    }
}
