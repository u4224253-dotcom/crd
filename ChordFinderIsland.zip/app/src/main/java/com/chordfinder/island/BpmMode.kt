package com.chordfinder.island

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val DIM = Color.White.copy(alpha = .5f)
private val ARC = Color(0xFF5EC2FF)

/**
 * Mode 5 — BPM (khusus tool BPM Finder). Lingkaran berdenyut mengikuti tempo, angka BPM besar,
 * keterangan kestabilan tempo, serta tombol Ulangi dan Ganti file.
 *
 * [result] = hasil pekerjaan tempo island ini (null selama belum ada); [name] = nama file;
 * [onGoUpload] = ke mode Upload kalau belum ada hasil.
 */
@Composable
fun BpmMode(
    result: ChordHub.St.Done?,
    name: String,
    onAgain: () -> Unit,
    onChange: () -> Unit,
    onGoUpload: () -> Unit,
) {
    if (result == null) {
        CText("Belum ada hasil tempo", Tok.W / 2f, 34f, 14f, weight = FontWeight.SemiBold)
        CText("Pilih file audio dulu di mode Upload", Tok.W / 2f, 52f, 11f, color = DIM)
        Pill(Tok.W / 2f - 50f, 62f, 100f, 24f, "Ke Upload", ICON_UPLOAD, onGoUpload)
        return
    }

    val bpm = result.bpm

    // denyut: satu kali per beat, mulai terang lalu meredup
    val pulse = remember { Animatable(0f) }
    LaunchedEffect(bpm) {
        if (bpm == null || bpm <= 0.0) { pulse.snapTo(0f); return@LaunchedEffect }
        val period = (60000.0 / bpm).toInt().coerceIn(240, 2400)
        while (true) {
            pulse.snapTo(1f)
            pulse.animateTo(0f, tween(period, easing = LinearEasing))
        }
    }

    Canvas(Modifier.placeAt(66f, 48f).size(44.dp)) {
        val k = size.width / 30f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(Color.White.copy(alpha = .18f), radius = 11f * k, center = c, style = Stroke(width = 3.2f * k))
        val t = pulse.value
        drawCircle(ARC.copy(alpha = .35f + .65f * t), radius = (5f + 5f * t) * k, center = c)
    }

    if (bpm != null) {
        CText(ChordHub.bpmText(bpm), 100f, 36f, 30f, weight = FontWeight.Bold, ax = 0f, maxW = 92f)
        val steady = result.steady ?: 0f
        val note = when {
            steady >= 0.85f -> "BPM · stabil"
            steady >= 0.6f -> "BPM · cukup stabil"
            else -> "BPM · berubah"
        }
        CText(note, 100f, 64f, 11f, color = DIM, ax = 0f, maxW = 96f)
    } else {
        CText("Tempo tidak terdeteksi", 100f, 36f, 14f, weight = FontWeight.SemiBold, ax = 0f, maxW = 150f)
        CText("Beat terlalu sedikit", 100f, 56f, 11f, color = DIM, ax = 0f, maxW = 150f)
    }

    CText(name, 198f, 26f, 12f, color = DIM, ax = 0f, maxW = 178f)
    Pill(198f, 40f, 78f, 24f, "Ulangi", ICON_AGAIN, onAgain)
    Pill(284f, 40f, 92f, 24f, "Ganti file", ICON_UPLOAD, onChange)
}
