package com.chordfinder.island

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

private const val TOOL_W = 74f
private const val TOOL_H = 76f
private const val GAP = 20f

/**
 * Mode 1 (default): Pilih tools. Dua kartu — Chord Finder dan BPM Finder, tanpa label status
 * (dulu "Aktif" / "Segera" di mock-up, sekarang dihapus). Ketuk Chord Finder = sesaat kemudian
 * pindah otomatis ke mode Upload, sama seperti alur di mock-up (pilih dulu, baru pindah).
 * Ketuk BPM Finder = baru menyorot kartunya (tool-nya sendiri belum ada).
 */
@Composable
fun ToolsMode(onChord: () -> Unit) {
    var sel by remember { mutableStateOf("chord") }
    var chordTap by remember { mutableIntStateOf(0) }
    LaunchedEffect(chordTap) {
        if (chordTap > 0) { delay(280); onChord() }
    }

    val totalW = TOOL_W * 2f + GAP
    val left0 = Tok.W / 2f - totalW / 2f
    val left1 = left0 + TOOL_W + GAP

    ToolCard(left0, selected = sel == "chord", label = "Chord Finder", onClick = { sel = "chord"; chordTap++ }) { color ->
        ChordIcon(color)
    }
    ToolCard(left1, selected = sel == "bpm", label = "BPM Finder", onClick = { sel = "bpm" }) { color ->
        BpmIcon(color)
    }
}

@Composable
private fun ToolCard(
    left: Float, selected: Boolean, label: String,
    onClick: () -> Unit, icon: @Composable (Color) -> Unit,
) {
    val bg = Color.White.copy(alpha = if (selected) .14f else .05f)
    val iconColor = Color.White.copy(alpha = if (selected) 1f else .6f)
    Box(
        Modifier
            .placeAt(left, 10f, ax = 0f, ay = 0f)
            .size(TOOL_W.dp, TOOL_H.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(top = 11.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            icon(iconColor)
            BasicText(
                label,
                modifier = Modifier.padding(top = 9.dp),
                style = TextStyle(
                    color = Color.White, fontWeight = FontWeight.SemiBold,
                    fontSize = with(LocalDensity.current) { 10.5f.dp.toSp() },
                ),
            )
        }
    }
}

/** Ikon kotak akor (fretboard mini + tiga titik jari), sama seperti di mock-up. ViewBox 24x24. */
@Composable
private fun ChordIcon(color: Color) {
    Canvas(Modifier.size(28.dp)) {
        val k = density * (28f / 24f)
        scale(k, k, Offset.Zero) {
            val rect = Path().apply {
                moveTo(6.5f, 3.5f); lineTo(17.5f, 3.5f); lineTo(17.5f, 20.5f); lineTo(6.5f, 20.5f); close()
            }
            val stroke = Stroke(width = 1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(rect, color, style = stroke)
            drawLine(color, Offset(6.5f, 9.2f), Offset(17.5f, 9.2f), strokeWidth = 1.7f, cap = StrokeCap.Round)
            drawLine(color, Offset(6.5f, 14.8f), Offset(17.5f, 14.8f), strokeWidth = 1.7f, cap = StrokeCap.Round)
            drawLine(color, Offset(10.2f, 3.5f), Offset(10.2f, 20.5f), strokeWidth = 1.7f, cap = StrokeCap.Round)
            drawLine(color, Offset(13.8f, 3.5f), Offset(13.8f, 20.5f), strokeWidth = 1.7f, cap = StrokeCap.Round)
            drawCircle(color, radius = 1.3f, center = Offset(12f, 6.4f))
            drawCircle(color, radius = 1.3f, center = Offset(8.4f, 12f))
            drawCircle(color, radius = 1.3f, center = Offset(15.6f, 17.6f))
        }
    }
}

/** Ikon gelombang pulsa (BPM), sama seperti di mock-up. ViewBox 24x24. */
@Composable
private fun BpmIcon(color: Color) {
    Canvas(Modifier.size(28.dp)) {
        val k = density * (28f / 24f)
        scale(k, k, Offset.Zero) {
            val p = Path().apply {
                moveTo(2.5f, 12.5f); lineTo(6.5f, 12.5f); lineTo(8.7f, 5.5f); lineTo(12f, 19.5f)
                lineTo(15f, 9f); lineTo(16.8f, 12.5f); lineTo(21.5f, 12.5f)
            }
            drawPath(p, color, style = Stroke(width = 1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}
