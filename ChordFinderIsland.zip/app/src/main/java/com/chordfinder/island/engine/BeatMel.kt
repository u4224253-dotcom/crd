package com.chordfinder.island.engine

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.ln1p
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Frontend Beat This! (CPJKU, ISMIR 2024): audio mono 22.050 Hz -> log-mel 128 pita, 50 frame/detik.
 *
 * Sama dengan torchaudio.MelSpectrogram(n_fft=1024, hop=441, f_min=30, f_max=11000, n_mels=128,
 * mel_scale="slaney", power=1, normalized="frame_length", center=True, pad_mode="reflect") lalu log1p(1000 * x).
 * Hasilnya diuji lawan port C++ beat_this_cpp (tools/beat/mel_parity.sh).
 *
 * Satu instance aman dipakai berulang, tetapi satu pemanggilan [compute] pada satu waktu.
 */
internal class BeatMel {
    /** [data] berukuran frames * N_MELS, urut per frame. */
    class Result(val frames: Int, val data: FloatArray)

    private val fft = Fft(N_FFT)
    private val window = FloatArray(N_FFT) { (0.5 * (1.0 - cos(2.0 * PI * it / N_FFT))).toFloat() }

    // Filter segitiga jarang: pita m hanya berisi bin [lo[m], hi[m]] dengan bobot w[m][..].
    private val lo = IntArray(N_MELS)
    private val hi = IntArray(N_MELS)
    private val w = arrayOfNulls<FloatArray>(N_MELS)

    init {
        val melMin = hzToMel(F_MIN)
        val melMax = hzToMel(F_MAX)
        val hz = DoubleArray(N_MELS + 2) { melToHz(melMin + (melMax - melMin) * it / (N_MELS + 1)) }
        val nBins = N_FFT / 2 + 1
        for (m in 0 until N_MELS) {
            val left = hz[m]; val center = hz[m + 1]; val right = hz[m + 2]
            var first = -1
            var last = -1
            val tmp = DoubleArray(nBins)
            for (k in 0 until nBins) {
                val f = k.toDouble() * SAMPLE_RATE / N_FFT
                val up = if (center - left != 0.0) (f - left) / (center - left) else 0.0
                val down = if (right - center != 0.0) (right - f) / (right - center) else 0.0
                val v = max(0.0, min(up, down))
                tmp[k] = v
                if (v > 0.0) { if (first < 0) first = k; last = k }
            }
            if (first < 0) { lo[m] = 0; hi[m] = -1; w[m] = FloatArray(0) }
            else {
                lo[m] = first; hi[m] = last
                w[m] = FloatArray(last - first + 1) { tmp[first + it].toFloat() }
            }
        }
    }

    /**
     * @param audio mono, 22.050 Hz.
     * @param onProgress 0..1 (boleh melempar untuk membatalkan).
     * Audio lebih pendek dari ~0,03 detik menghasilkan 0 frame.
     */
    fun compute(audio: FloatArray, onProgress: ((Float) -> Unit)? = null): Result {
        val n = audio.size
        val pad = N_FFT / 2
        if (n <= pad) return Result(0, FloatArray(0))
        val frames = n / HOP + 1          // (n + 2*pad - N_FFT) / HOP + 1
        val out = FloatArray(frames * N_MELS)
        val re = FloatArray(N_FFT)
        val im = FloatArray(N_FFT)
        val amp = FloatArray(N_FFT / 2 + 1)
        val norm = 1.0f / sqrt(N_FFT.toFloat())      // normalized = "frame_length"

        for (f in 0 until frames) {
            val start = f * HOP - pad                  // indeks pada audio asli (bisa negatif = padding)
            for (j in 0 until N_FFT) {
                var idx = start + j
                if (idx < 0) idx = -idx                              // refleksi kiri (tanpa mengulang tepi)
                else if (idx >= n) idx = 2 * (n - 1) - idx           // refleksi kanan
                re[j] = audio[idx] * window[j]
                im[j] = 0f
            }
            fft.transform(re, im)
            for (k in amp.indices) amp[k] = sqrt(re[k] * re[k] + im[k] * im[k]) * norm
            val base = f * N_MELS
            for (m in 0 until N_MELS) {
                val wm = w[m]!!
                var e = 0.0
                val l = lo[m]
                for (i in wm.indices) e += amp[l + i] * wm[i]
                out[base + m] = ln1p(LOG_MULT * max(e, AMIN)).toFloat()
            }
            if (onProgress != null && f % 512 == 0) onProgress(f.toFloat() / frames)
        }
        onProgress?.invoke(1f)
        return Result(frames, out)
    }

    companion object {
        const val SAMPLE_RATE = 22050
        const val N_FFT = 1024
        const val HOP = 441
        const val N_MELS = 128
        const val FPS = 50f                    // 22050 / 441
        private const val F_MIN = 30.0
        private const val F_MAX = 11000.0
        private const val LOG_MULT = 1000.0
        private const val AMIN = 1e-10

        // Skala mel Slaney (linear di bawah 1 kHz, logaritmik di atasnya)
        private const val F_SP = 200.0 / 3.0
        private const val MIN_LOG_HZ = 1000.0
        private val MIN_LOG_MEL = MIN_LOG_HZ / F_SP
        private val LOG_STEP = ln(6.4) / 27.0

        private fun hzToMel(hz: Double): Double =
            if (hz >= MIN_LOG_HZ) MIN_LOG_MEL + ln(hz / MIN_LOG_HZ) / LOG_STEP else hz / F_SP

        private fun melToHz(mel: Double): Double =
            if (mel >= MIN_LOG_MEL) MIN_LOG_HZ * exp(LOG_STEP * (mel - MIN_LOG_MEL)) else mel * F_SP
    }
}
