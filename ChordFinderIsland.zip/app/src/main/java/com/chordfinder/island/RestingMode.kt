package com.chordfinder.island

import android.graphics.BlurMaskFilter
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.abs
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Mode Resting (.l-pet di HTML): island menciut jadi pil 150 x 30 dp, ada cahaya gradien
 * (--glow: cyan, indigo 55%, violet) yang naik dari bawah, dan sepasang mata putih.
 * Mata menoleh pelan (kiri, kanan, atas, bawah, diagonal) dan berkedip acak dengan beberapa ekspresi
 * (kedip biasa, dobel, sebelah, menyipit, ngantuk, melek lebar).
 * Dipakai di tengah cangkang yang sedang berubah ukuran, jadi semua ukuran mengikuti ruang yang ada.
 */
private val GLOW_CYAN = Color(0xFF19B8FF)
private val GLOW_INDIGO = Color(0xFF2D5BFF)
private val GLOW_VIOLET = Color(0xFF7B4BFF)

private const val EYE_W = 8.4f
private const val EYE_H = 12.4f
private const val EYE_GAP = 15f

// Menoleh: geser maksimum mata (dp), geser cahaya bawah (dp), dan lebar ekstra cahaya supaya tepinya tidak bolong.
private const val LOOK_MAX_X = 20f
private const val LOOK_MAX_Y = 5f
private const val AMBIENT_SHIFT = 4f
private const val AMBIENT_BLEED = 8f

// cubic-bezier(.3,1.1,.5,1) = gerak halus dengan sedikit memantul di ujung; kedip memakai ease-in-out.
private val LookEase = CubicBezierEasing(.3f, 1.1f, .5f, 1f)
private val BlinkEase = CubicBezierEasing(.42f, 0f, .58f, 1f)

private val LOOK_SPOTS = listOf(
    -1f to 0f, 1f to 0f, 0f to -1f, 0f to 1f,
    -1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f,
    -.6f to 0f, .6f to -.6f,
)

/** box-shadow CSS (blur) ke radius BlurMaskFilter: sigma = blur / 2, radius = (sigma - .5) / .57735. */
private fun cssBlur(blurPx: Float): Float = ((blurPx / 2f - .5f) / .57735f).coerceAtLeast(.1f)

private fun rnd(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)
private fun rndMs(a: Int, b: Int): Int = Random.nextInt(a, b + 1)

/** Status animasi: arah pandang (-1..1, kiri/atas negatif) dan skala tinggi tiap mata (1 = terbuka). */
private class RestingState {
    val lookX = Animatable(0f)
    val lookY = Animatable(0f)
    val blinkL = Animatable(1f)
    val blinkR = Animatable(1f)
}

private suspend fun RestingState.look(x: Float, y: Float) = coroutineScope {
    val spec = tween<Float>(durationMillis = 800, easing = LookEase)
    launch { lookX.animateTo(x, spec) }
    launch { lookY.animateTo(y, spec) }
}

/**
 * Satu kedipan: terbuka -> [closed] -> terbuka. [hold] = porsi waktu mata bertahan di posisi [closed]
 * (0 = langsung buka lagi). closed < 1 = menutup, closed > 1 = melek lebar.
 */
private suspend fun Animatable<Float, AnimationVector1D>.blinkTo(durMs: Int, closed: Float, hold: Float) {
    animateTo(
        1f,
        keyframes {
            durationMillis = durMs
            if (hold > 0f) {
                val o1 = (.5f - hold / 2f).coerceAtLeast(.15f)
                val o2 = (.5f + hold / 2f).coerceAtMost(.85f)
                1f at 0 using BlinkEase
                closed at (durMs * o1).toInt() using BlinkEase
                closed at (durMs * o2).toInt() using BlinkEase
                1f at durMs using BlinkEase
            } else {
                1f at 0 using BlinkEase
                closed at (durMs * .45f).toInt() using BlinkEase
                1f at durMs using BlinkEase
            }
        },
    )
}

private suspend fun RestingState.both(durMs: Int, closed: Float, hold: Float) = coroutineScope {
    launch { blinkL.blinkTo(durMs, closed, hold) }
    launch { blinkR.blinkTo(durMs, closed, hold) }
}

@Composable
fun RestingMode() {
    val st = remember { RestingState() }

    // Menoleh: pilih arah acak, tahan 2.2-4 dtk, balik ke tengah, istirahat 1.8-4 dtk.
    LaunchedEffect(st) {
        delay(1600)
        while (true) {
            val (x, y) = LOOK_SPOTS.random()
            launch { st.look(x, y) }
            delay(rndMs(2200, 4000).toLong())
            launch { st.look(0f, 0f) }
            delay(rndMs(1800, 4000).toLong())
        }
    }

    // Kedip acak dengan beberapa ekspresi; jeda antar kedipan 0.7-5.5 dtk.
    LaunchedEffect(st) {
        delay(1500)
        while (true) {
            when (Random.nextInt(98)) {
                in 0 until 70 -> st.both(rndMs(90, 500), rnd(.04f, .26f), 0f)        // kedip biasa (cepat/pelan)
                in 70 until 80 -> {                                                   // kedip dobel
                    st.both(rndMs(90, 200), .06f, 0f)
                    delay(rndMs(60, 150).toLong())
                    st.both(rndMs(90, 200), .06f, 0f)
                }
                in 80 until 82 -> st.blinkL.blinkTo(rndMs(220, 480), .05f, .25f)      // kedip kiri (jarang)
                in 82 until 84 -> st.blinkR.blinkTo(rndMs(220, 480), .05f, .25f)      // kedip kanan (jarang)
                in 84 until 89 -> st.both(rndMs(700, 1100), .42f, .6f)                // menyipit
                in 89 until 94 -> st.both(rndMs(900, 1400), .03f, .4f)                // kedip ngantuk, pelan
                else -> st.both(rndMs(600, 900), 1.16f, .55f)                         // melek lebar
            }
            delay(rndMs(700, 5500).toLong())
        }
    }

    Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
        val lx = st.lookX.value
        val ly = st.lookY.value
        drawAmbient(shiftPx = -lx * AMBIENT_SHIFT * density)
        drawEyes(lx, ly, st.blinkL.value, st.blinkR.value)
    }
}

/** .ambient: tinggi 90 persen dari bawah, gradien --glow, di-mask memudar ke atas; ikut bergeser tipis saat menoleh. */
private fun DrawScope.drawAmbient(shiftPx: Float) {
    val h = size.height * .9f
    val top = size.height - h
    val bleed = AMBIENT_BLEED * density
    val left = -bleed + shiftPx
    val w = size.width + bleed * 2f
    val area = Size(w, h)
    drawRect(
        brush = Brush.horizontalGradient(
            0f to GLOW_CYAN, .55f to GLOW_INDIGO, 1f to GLOW_VIOLET,
            startX = left, endX = left + w,
        ),
        topLeft = Offset(left, top), size = area,
    )
    // mask: to top, #000 0%, .55 30%, .12 70%, transparan 100%  ->  dari atas: 0, .12, .55, 1
    drawRect(
        brush = Brush.verticalGradient(
            0f to Color.Black.copy(alpha = 0f),
            .30f to Color.Black.copy(alpha = .12f),
            .70f to Color.Black.copy(alpha = .55f),
            1f to Color.Black,
            startY = top, endY = size.height,
        ),
        topLeft = Offset(left, top), size = area,
        blendMode = BlendMode.DstIn,
    )
}

/**
 * Dua mata oval putih 8.4 x 12.4, jarak 15; ada cahaya biru (dua lapis box-shadow).
 * Saat menoleh, mata bergeser ke arah pandang dan mata di sisi yang dituju sedikit menyempit.
 */
private fun DrawScope.drawEyes(lx: Float, ly: Float, blinkL: Float, blinkR: Float) {
    val d = density
    val ew = EYE_W * d
    val gap = EYE_GAP * d
    val cx = size.width / 2f + lx * LOOK_MAX_X * d
    val cy = size.height / 2f + ly * LOOK_MAX_Y * d
    val squeezeL = if (lx < 0f) 1f - abs(lx) * .15f else 1f
    val squeezeR = if (lx > 0f) 1f - abs(lx) * .15f else 1f
    drawEye(cx - gap / 2f - ew / 2f, cy, ew * squeezeL, EYE_H * d * blinkL)
    drawEye(cx + gap / 2f + ew / 2f, cy, ew * squeezeR, EYE_H * d * blinkR)
}

private fun DrawScope.drawEye(centerX: Float, centerY: Float, w: Float, h: Float) {
    val d = density
    val x = centerX - w / 2f
    val y = centerY - h / 2f
    drawIntoCanvas { c ->
        val n = c.nativeCanvas
        fun glow(spread: Float, blurCss: Float, color: Int) {
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                maskFilter = BlurMaskFilter(cssBlur(blurCss * d), BlurMaskFilter.Blur.NORMAL)
            }
            val s = spread * d
            n.drawOval(x - s, y - s, x + w + s, y + h + s, p)
        }
        glow(4f, 14f, android.graphics.Color.argb(71, 80, 140, 255))    // 0 0 14px 4px rgba(80,140,255,.28)
        glow(1f, 6f, android.graphics.Color.argb(153, 120, 190, 255))   // 0 0 6px 1px rgba(120,190,255,.6)
    }
    drawOval(Color.White, topLeft = Offset(x, y), size = Size(w, h))
}
