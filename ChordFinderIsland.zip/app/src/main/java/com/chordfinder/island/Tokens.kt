package com.chordfinder.island

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.ui.graphics.Color
import kotlin.math.roundToInt

/** Semua angka di sini disalin dari versi HTML (1 px CSS = 1 dp). */
object Tok {
    const val W = 420f      // lebar island (semua mode sama)
    const val H = 96f       // tinggi island
    const val R = 28f       // radius sudut bawah
    const val E = 20f       // telinga (fillet) kiri-kanan

    // Mode resting (data-s="pet" di HTML): pil kecil 150 x 30 dengan mata
    const val RW = 150f
    const val RH = 30f
    const val RR = 14f
    const val RE = 10f

    val Spring = CubicBezierEasing(0.34f, 1.32f, 0.5f, 1f)   // --spring
    val Ease = CubicBezierEasing(0.25f, 0.1f, 0.25f, 1f)      // CSS "ease"
    val EaseInOut = CubicBezierEasing(0.42f, 0f, 0.58f, 1f)   // CSS "ease-in-out"

    // PAL maskot: cyan, indigo, violet
    val Pal = listOf(intArrayOf(40, 170, 240), intArrayOf(52, 104, 236), intArrayOf(104, 78, 222))
}

const val MSG_DEFAULT = "Taruh file audio di sini"
const val MSG_BAD = "Itu bukan file audio"

fun rgba(c: IntArray, a: Float): Color = Color(c[0] / 255f, c[1] / 255f, c[2] / 255f, a.coerceIn(0f, 1f))
fun rgba(r: Int, g: Int, b: Int, a: Float): Color = Color(r / 255f, g / 255f, b / 255f, a.coerceIn(0f, 1f))

fun shCl(x: Float, a: Float = 0f, b: Float = 1f): Float = minOf(b, maxOf(a, x))
fun shSm(x: Float): Float { val t = shCl(x); return t * t * (3f - 2f * t) }

fun shMix(u: Float): IntArray {
    val x = shCl(u)
    val a: IntArray; val b: IntArray; val k: Float
    if (x < .5f) { a = Tok.Pal[0]; b = Tok.Pal[1]; k = x * 2f } else { a = Tok.Pal[1]; b = Tok.Pal[2]; k = (x - .5f) * 2f }
    return IntArray(3) { (a[it] + (b[it] - a[it]) * k).roundToInt() }
}
