package com.chordfinder.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Fase mode 1: Upload, Analisis, Selesai (sama dengan data-s up / an / done di HTML). */
enum class Phase { UP, AN, DONE }

/** Sama seperti fmt() di HTML: detik menjadi mm:ss. */
fun fmtTime(sec: Float): String {
    val s = max(0, sec.roundToInt())
    return (s / 60).toString().padStart(2, '0') + ":" + (s % 60).toString().padStart(2, '0')
}

/**
 * Alur mode 1: file diterima, cahaya naik + tegukan, tunggu 750 ms, lalu mesin akor ([ChordHub]) bekerja.
 * Progres, tahap, dan sisa waktu yang tampil berasal dari mesin; cahaya ambient island naik mengikutinya.
 * Hasil akor tetap disimpan di [ChordHub] (dipakai mode Akor).
 */
class AnalyzeFlow(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val glow: GlowController,
    private val onFail: (String) -> Unit,
) {
    var phase by mutableStateOf(Phase.UP); private set
    var progress by mutableFloatStateOf(0f); private set
    var name by mutableStateOf("audio"); private set
    var stage by mutableStateOf(ChordHub.STAGE_READ); private set
    /** Perkiraan sisa waktu (detik); null = belum bisa diperkirakan. */
    var eta by mutableStateOf<Float?>(null); private set

    private var job: Job? = null
    private var info: PickedAudio? = null
    private var ticket = 0      // tiket pekerjaan di ChordHub milik island ini; 0 = tidak punya

    /** Hasil akor pekerjaan island ini; null selama belum selesai (atau sudah diganti/dibatalkan). */
    val chords: ChordHub.St.Done?
        get() {
            val s = ChordHub.state
            return if (phase == Phase.DONE && s is ChordHub.St.Done && s.id == ticket) s else null
        }

    fun accept(info: PickedAudio) {
        this.info = info
        name = info.name
        glow.drop()
        stopWork()
        job = scope.launch { delay(750); analyze() }
    }

    fun again() {
        stopWork()
        job = scope.launch { analyze() }
    }

    fun reset() {
        stopWork()
        glow.reset()
        phase = Phase.UP
    }

    /** Island ditutup: hentikan pekerjaan yang masih jalan supaya tidak membuang baterai tanpa ada yang melihat. */
    fun release() = stopWork()

    /**
     * Layar aplikasi ditutup (mis. di-swipe dari recent) tapi analisisnya dibiarkan lanjut di [ChordHub]
     * (dijaga AnalysisService). Hanya melepas pemantau island ini; pekerjaan dan hasilnya tidak disentuh.
     */
    fun detach() {
        job?.cancel(); job = null
        ticket = 0
    }

    /** Island baru (app dibuka lagi) menyambung ke pekerjaan [id] yang masih berjalan atau sudah selesai di [ChordHub]. */
    fun adopt(info: PickedAudio, id: Int) {
        stopWork()
        this.info = info
        name = info.name
        ticket = id
        job = scope.launch {
            phase = Phase.AN; progress = 0f; stage = ChordHub.STAGE_READ; eta = null
            glow.waterStart()
            follow(id)
        }
    }

    private fun stopWork() {
        job?.cancel(); job = null
        if (ticket != 0) ChordHub.cancel(ticket)
        ticket = 0
    }

    /** Pekerjaan hilang tanpa lewat island ini: kembali ke mode Upload. */
    private fun giveUp() {
        ticket = 0
        glow.waterStop(); glow.reset()
        phase = Phase.UP
    }

    private suspend fun analyze() {
        val src = info ?: return
        phase = Phase.AN; progress = 0f; stage = ChordHub.STAGE_READ; eta = null
        glow.waterStart()
        val my = ChordHub.start(ctx, src)
        ticket = my
        follow(my)
    }

    /** Pantau pekerjaan [my] di [ChordHub] sampai selesai: progres halus, lalu fase Selesai (atau kembali ke Upload kalau gagal/dibatalkan). */
    private suspend fun follow(my: Int) {
        var shown = 0f
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            val st = ChordHub.state
            if (st.id != my) { giveUp(); return } // dibatalkan / digantikan dari luar (mis. tombol di notifikasi)
            var target = shown
            when (st) {
                is ChordHub.St.Working -> { target = st.p; stage = st.stage; eta = st.etaSec }
                is ChordHub.St.Done -> target = 1f
                is ChordHub.St.Fail -> {
                    ticket = 0
                    glow.waterStop(); glow.reset()
                    phase = Phase.UP
                    onFail(st.msg)
                    return
                }
                ChordHub.St.Idle -> { giveUp(); return }
            }
            shown = max(shown, shown + (target - shown) * min(1f, dt * 8f))   // menuju target dengan halus, tidak pernah mundur
            progress = shown
            glow.waterLevel(shown)
            if (st is ChordHub.St.Done && shown > 0.995f) break
        }
        progress = 1f
        glow.waterLevel(1f)
        delay(380)
        glow.waterStop()
        phase = Phase.DONE
    }
}
