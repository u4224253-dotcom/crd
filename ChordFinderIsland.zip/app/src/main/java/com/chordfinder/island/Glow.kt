package com.chordfinder.island

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Fisika cahaya "Island gulp" — port dari makeGlow() di versi HTML. */
class GlowController {
    var hov = 0f; var hv = 0f
    var dropT = -1f
    var dx = Tok.W / 2f; var cx = Tok.W / 2f
    var g = 0f; var gv = 0f
    var hot = false
    var t = 0f                                   // waktu animasi air
    var wl = 0f; var wt = 0f                     // tinggi air (sekarang / target)
    var wOn = false; var wA = 0f                 // air menyala / opasitas air
    var frame by mutableIntStateOf(0)
    var wake by mutableIntStateOf(0)

    fun hot(on: Boolean) { hot = on; wake++ }
    fun move(x: Float) { cx = shCl(x, 0f, Tok.W) }
    fun drop() { hot = false; dx = cx; dropT = 0f; gv = 7.7f; wake++ }

    fun waterStart() { wl = 0f; wt = 0f; wOn = true; wake++ }
    fun waterLevel(p: Float) { wt = p }
    fun waterStop() { wOn = false; wake++ }
    fun reset() {
        hot = false; hov = 0f; hv = 0f; dropT = -1f; g = 0f; gv = 0f
        wl = 0f; wt = 0f; wOn = false; wA = 0f
        frame++
    }

    fun busy(): Boolean = hot || hov > .002f || dropT >= 0f || abs(g) > .001f || abs(gv) > .01f || wOn || wA > .004f

    fun step(dt: Float) {
        hv += (50f * ((if (hot) 1f else 0f) - hov) - 14f * hv) * dt
        hov = shCl(hov + hv * dt, 0f, 1.04f)
        gv += (-60f * g - 6f * gv) * dt
        g += gv * dt
        if (dropT >= 0f) { dropT += dt * 0.7f; if (dropT >= 2f) dropT = -1f }
        t += dt
        wl += (wt - wl) * min(1f, dt * 6f)
        wA += ((if (wOn) 1f else 0f) - wA) * min(1f, dt * (if (wOn) 4f else 1.5f))
    }

    fun settle() { hov = 0f; hv = 0f; g = 0f; gv = 0f }
}

@Composable
fun GlowLoop(glow: GlowController) {
    LaunchedEffect(glow.wake) {
        var last = withFrameNanos { it }
        while (glow.busy()) {
            val now = withFrameNanos { it }
            val dt = min(0.05f, (now - last) / 1_000_000_000f)
            last = now
            glow.step(dt)
            glow.frame++
        }
        glow.settle()
        glow.frame++
    }
}

/**
 * Gambar dalam satuan 420 x 96 (sama seperti canvas HTML), titik 0 = tepi kiri badan.
 * Kanvas harus selebar badan + dua telinga (Layer bleed = true), cahaya ikut mengisi area telinga.
 * Wajib dipakai di layer Offscreen.
 */
fun DrawScope.drawIslandGlow(s: GlowController, k: Float = 1f) {
    val w = Tok.W; val h = Tok.H
    scale(density, density, Offset.Zero) { translate(Tok.E, 0f) {
        val ex = Tok.E
        val topLeft = Offset(-ex, 0f)
        val full = Size(w + 2f * ex, h)
        val d = s.dropT
        val rise = if (d >= 0f && d < 1.1f) sin(shSm(d / 1.1f) * PI).toFloat() else 0f
        val fade = if (d >= 0f) (if (d < .9f) 1f else 1f - shSm((d - .9f) / 1.1f)) else 1f
        val base = (.26f * s.hov + .34f * rise) * fade * k
        val pool = (.42f * s.hov + .28f * rise) * fade * k

        if (base > .004f) {
            drawRect(
                brush = Brush.horizontalGradient(
                    0f to rgba(Tok.Pal[0], base), .5f to rgba(Tok.Pal[1], base), 1f to rgba(Tok.Pal[2], base),
                    startX = 0f, endX = w,
                ),
                topLeft = topLeft, size = full,
            )
        }

        val px = if (d >= 0f) s.dx else s.cx
        if (pool > .004f) {
            val col = shMix(px / w)
            val light = IntArray(3) { min(255, col[it] + 51) }
            val r = 170f + 60f * rise
            drawRect(
                brush = Brush.radialGradient(
                    0f to rgba(light, pool), .55f to rgba(col, pool * .45f), 1f to rgba(col, 0f),
                    center = Offset(px, h + 18f), radius = r,
                ),
                topLeft = topLeft, size = full,
            )
        }

        if (d >= 0f && d < 1.4f) {
            val q = 1f - (1f - d / 1.4f).pow(3)
            val r = 24f + 430f * q
            val ww = 30f
            val a = .22f * (1f - q) * k
            val outer = r + ww
            val t0 = max(0f, r - ww) / outer
            val mid = t0 + (1f - t0) * .5f
            val c0 = rgba(200, 236, 255, 0f)
            drawRect(
                brush = Brush.radialGradient(
                    0f to c0, t0 to c0, mid to rgba(200, 236, 255, a), 1f to c0,
                    center = Offset(px, h - 14f), radius = outer,
                ),
                topLeft = topLeft, size = full,
            )
        }

        // cahaya memudar ke atas (destination-in)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f), .22f to Color.Black.copy(alpha = .08f),
                .58f to Color.Black.copy(alpha = .55f), 1f to Color.Black,
                startY = 0f, endY = h,
            ),
            topLeft = topLeft, size = full,
            blendMode = BlendMode.DstIn,
        )

        // cahaya ambient simetris (mode analisis), naik mengikuti progres
        if (s.wA > .004f) drawWater(s, k)
    } }
}

/**
 * Palet ambient mode analisis (kiri, tengah, kanan). Palet bergantian dengan crossfade halus tiap [PAL_DUR] detik.
 * Warnanya berdekatan, jadi perpindahan tidak pernah lewat warna keruh.
 */
private val AMBIENT_PALS = listOf(
    listOf(intArrayOf(40, 170, 240), intArrayOf(52, 104, 236), intArrayOf(104, 78, 222)),    // aurora (asli)
    listOf(intArrayOf(96, 190, 255), intArrayOf(140, 120, 255), intArrayOf(236, 130, 220)),  // biru ke lavender ke pink
    listOf(intArrayOf(60, 215, 205), intArrayOf(60, 150, 240), intArrayOf(120, 110, 250)),   // mint ke biru ke ungu
    listOf(intArrayOf(255, 150, 130), intArrayOf(235, 105, 170), intArrayOf(150, 95, 235)),  // senja lembut
)
private const val PAL_DUR = 7f

private fun ambientCol(c: FloatArray, alpha: Float) =
    Color(c[0] / 255f, c[1] / 255f, c[2] / 255f, alpha.coerceIn(0f, 1f))

/**
 * Cahaya ambient mode analisis (pengganti air bergelombang): simetris kiri-kanan.
 *  1. gradien simetris (tepi kiri = tepi kanan), palet bergantian halus;
 *  2. dua pendar kembar bergerak berlawanan (bersamaan ke tengah, bersamaan ke luar);
 *  3. progres menyebar dari tengah ke kiri dan kanan, penuh saat 100 persen;
 *  4. memudar ke atas, tinggi naik mengikuti progres, intensitas bernapas pelan.
 * Digambar di layer sendiri supaya mask DstIn tidak ikut menghapus cahaya island di bawahnya.
 */
private fun DrawScope.drawWater(s: GlowController, k: Float) {
    val h = Tok.H
    val wl = s.wl; val wA = s.wA; val t = s.t
    val top = h - (26f + (h - 26f) * wl)
    val a = .7f * wA * (.9f + .1f * sin(t * 1.6f)) * k

    val pos = t / PAL_DUR
    val fl = kotlin.math.floor(pos)
    val i0 = fl.toInt() % AMBIENT_PALS.size
    val i1 = (i0 + 1) % AMBIENT_PALS.size
    val f = shSm(pos - fl)
    fun mix(idx: Int): FloatArray {
        val p = AMBIENT_PALS[i0][idx]; val q = AMBIENT_PALS[i1][idx]
        return FloatArray(3) { p[it] + (q[it] - p[it]) * f }
    }
    val m0 = mix(0); val m1 = mix(1); val m2 = mix(2)

    val bounds = Rect(-Tok.E, 0f, Tok.W + Tok.E, h)
    drawContext.canvas.saveLayer(bounds, Paint())
    translate(-Tok.E, 0f) {                       // koordinat 0..460 (badan + dua telinga)
        val full = Size(Tok.W + 2f * Tok.E, h)
        val cxm = full.width / 2f

        drawRect(
            brush = Brush.horizontalGradient(
                0f to ambientCol(m0, a), .5f to ambientCol(m2, a), 1f to ambientCol(m0, a),
                startX = 0f, endX = full.width,
            ),
            size = full,
        )

        val sw = (sin(t * .6f) * .5f + .5f) * 150f
        for (x in floatArrayOf(cxm - 40f - sw, cxm + 40f + sw)) {
            val light = floatArrayOf(min(255f, m1[0] + 60f), min(255f, m1[1] + 60f), min(255f, m1[2] + 60f))
            drawRect(
                brush = Brush.radialGradient(
                    0f to ambientCol(light, .45f * wA * k), 1f to ambientCol(light, 0f),
                    center = Offset(x, h + 10f), radius = 130f + 20f * wl,
                ),
                size = full,
            )
        }

        val rx = 70f + 440f * wl
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Transparent, .22f to Color.Black, .78f to Color.Black, 1f to Color.Transparent,
                startX = cxm - rx, endX = cxm + rx,
            ),
            size = full, blendMode = BlendMode.DstIn,
        )
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f), .3f to Color.Black.copy(alpha = .12f),
                .7f to Color.Black.copy(alpha = .55f), 1f to Color.Black,
                startY = top, endY = h,
            ),
            size = full, blendMode = BlendMode.DstIn,
        )
    }
    drawContext.canvas.restore()
}
