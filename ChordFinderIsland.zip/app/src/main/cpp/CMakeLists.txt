cmake_minimum_required(VERSION 3.18)
project(cfcnn LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(cfcnn SHARED cnn_core.cpp cnn_jni.cpp)

# -O3 supaya loop vektor (tipe vector_size) jadi NEON; -fno-math-errno agar std::expm1 tidak menyentuh errno
target_compile_options(cfcnn PRIVATE -O3 -fno-math-errno -Wall -Wextra)

# Halaman 16 KB (syarat perangkat Android baru); aman di perangkat lama
target_link_options(cfcnn PRIVATE -Wl,-z,max-page-size=16384)

find_library(log-lib log)
target_link_libraries(cfcnn ${log-lib})
